﻿#include "stdafx.h"
#include "Particle.h"
#include "Scene.h"

CParticle::CParticle()
{
	SetObjectType(OBJ_EFFECT);

	if (SCENE_MANAGER && SCENE_MANAGER->GetCurrentScene())
	{
		SetMesh(SCENE_MANAGER->GetCurrentScene()->GetParticleMesh());
	}
}

CParticle::~CParticle()
{
}

void CParticle::Explode(XMFLOAT3 startPos, int count, COLORREF color, float lT )
{
	SetPosition(startPos);

	for (int i = 0; i < count; i++)
	{
		Particle particle;
		particle.position = startPos;
		particle.velocity = XMFLOAT3(
			(rand() % 100 - 50) / 10.0f,
			(rand() % 100 - 50) / 10.0f,
			(rand() % 100 - 50) / 10.0f
		);
		particle.lifeTime = lT; // 입자의 생존 시간 (초)
		particle.color = color;
		m_particles.push_back(particle);
	}
}

void CParticle::Update()
{
	CGameObject::Update(); // 부모 클래스의 Update()를 호출하여 월드 행렬 갱신
	float deltaTime = TIMER->GetTimeElapsed();

	for (int i = 0; i < (int)m_particles.size();) {
		m_particles[i].lifeTime -= deltaTime;
		if (m_particles[i].lifeTime > 0)
		{
			m_particles[i].position = Vector3::Add(m_particles[i].position, m_particles[i].velocity, deltaTime);
			++i;
		}
		else
		{
			m_particles[i] = m_particles.back();
			m_particles.pop_back();
		}
	}

	if(m_particles.empty())
	{
		SetDestroyed(true); // 모든 입자가 사라지면 이 파티클 객체도 제거 대상으로 표시
	}
}
// [변경] Render — D3D12 버전
//
// 각 파티클을 작은 큐브로 렌더링한다.
//   1) 파티클마다 m_xmf4x4World를 (Scale × Translate)로 재계산
//   2) 부모 CGameObject::Render 호출
//      → 내부에서 PSO 바인딩 + UpdateShaderVariables(b0) + Mesh::Render
//
// 주의: 현재 옵션 C 구조에서는 한 폭발의 모든 파티클이 동일한 CBV(b0)를 공유하므로
//       매 파티클마다 UpdateShaderVariables 호출로 World 행렬이 갱신된다.
//       N개 파티클 = N번의 SetGraphicsRootConstantBufferView + N번의 DrawIndexed.
//       (Phase 9 인스턴싱으로 N개 → 1번의 DrawCall로 최적화 예정)
void CParticle::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera)
{
	if (m_particles.empty()) return;

	for (const auto& particle : m_particles)
	{
		XMMATRIX mtxScale = XMMatrixScaling(0.3f, 0.3f, 0.3f);

		XMMATRIX mtxTranslate = XMMatrixTranslation(particle.position.x, particle.position.y, particle.position.z);
		XMStoreFloat4x4(&m_xmf4x4World, XMMatrixMultiply(mtxScale, mtxTranslate));
		SetColor(particle.color);

		
		CGameObject::Render(pd3dCommandList, pCamera);
	}
}
