﻿// [Phase 3 변환]
// - 6종 메시 모두 D3D12 정점/인덱스 버퍼로 업로드
// - 정점/인덱스 데이터는 기존 GDI 버전과 동일 (좌표·순서 보존)
//
#include "stdafx.h"
#include "Mesh.h"
#include "GraphicsHelpers.h" //CreateBufferResource 사용



#define RANDOM_COLOR XMFLOAT4( \
    1.0f, \
    1.0f, \
    1.0f, \
    1.0f)
// CMesh 

CMesh::CMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList)
{
}

CMesh::~CMesh()
{
	// [D3D12 추가] GPU 리소스 해제
	if (m_pd3dVertexBuffer) m_pd3dVertexBuffer->Release();
	if (m_pd3dVertexUploadBuffer) m_pd3dVertexUploadBuffer->Release();
	if (m_pd3dIndexBuffer) m_pd3dIndexBuffer->Release();
	if (m_pd3dIndexUploadBuffer) m_pd3dIndexUploadBuffer->Release();

}

void CMesh::ReleaseUploadBuffers()
{
	// CommandList 실행 완료 후 임시 업로드 버퍼 해제 (CGameFramework::BuildObjects에서 호출)
	if (m_pd3dVertexUploadBuffer) m_pd3dVertexUploadBuffer->Release();
	m_pd3dVertexUploadBuffer = NULL;

	if (m_pd3dIndexUploadBuffer) m_pd3dIndexUploadBuffer->Release();
	m_pd3dIndexUploadBuffer = NULL;

}


// OBB Extents 계산 — 기존 GDI 버전 GetBoundingBoxExtents()와 동일한 알고리즘
// 정점 배열을 순회하며 (max - min) / 2 를 추출한다.
void CMesh::CalculateBoundingBoxExtents(const CDiffusedVertex* pVertices, UINT nVertices)
{
	if (!pVertices || nVertices == 0) {
		m_xmf3Extents = XMFLOAT3(0.0f, 0.0f, 0.0f);
		return;
	}

	// CDiffusedVertex의 첫 멤버가 XMFLOAT3 위치 - 동일 메모리 레이아웃 활용
	const XMFLOAT3* p0 = reinterpret_cast<const XMFLOAT3*>(&pVertices[0]);
	float maxX = p0->x; float maxY = p0->y; float maxZ = p0->z;
	float minX = p0->x; float minY = p0->y; float minZ = p0->z;

	for (UINT i = 1; i < nVertices; ++i)
	{
		const XMFLOAT3* p = reinterpret_cast<const XMFLOAT3*>(&pVertices[i]);
		if (p->x > maxX) maxX = p->x; if (p->y > maxY) maxY = p->y; if (p->z > maxZ) maxZ = p->z;
		if (p->x < minX) minX = p->x; if (p->y < minY) minY = p->y; if (p->z < minZ) minZ = p->z;
	}

	m_xmf3Extents = XMFLOAT3(
		(maxX- minX) * 0.5f,
		(maxY - minY) * 0.5f,
		(maxZ - minZ) * 0.5f
	);

}
// CMesh::Render — IA 단계 바인딩 후 인덱스 기반 드로우 콜
// (기존 GDI: 삼각형마다 Polygon() 호출 → GPU의 DrawIndexedInstanced 한 번으로 대체)

void CMesh::Render(ID3D12GraphicsCommandList* pd3dCommandList)
{
	pd3dCommandList->IASetPrimitiveTopology(m_d3dPrimitiveTopology);
	pd3dCommandList->IASetVertexBuffers(m_nSlot, 1, &m_d3dVertexBufferView);

	if (m_pd3dIndexBuffer) {
		pd3dCommandList->IASetIndexBuffer(&m_d3dIndexBufferView);
		pd3dCommandList->DrawIndexedInstanced(m_nIndices, 1, m_nStartIndex, m_nBaseVertex, 0);
	}
	else 
		pd3dCommandList->DrawInstanced(m_nVertices, 1, m_nOffset, 0);
}


XMFLOAT3 CMesh::GetBoundingBoxExtents() const
{
	
	return m_xmf3Extents;
}

CCubeMesh::CCubeMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList
	, float fWHD)
	: CMesh(pd3dDevice, pd3dCommandList)
{
	float fx = fWHD * 0.5f;
	float fy = fWHD * 0.5f;
	float fz = fWHD * 0.5f;

	// 1. 점 8개 생성
	m_nVertices = 8;
	m_nStride = sizeof(CDiffusedVertex);
	m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	
	std::array<CDiffusedVertex, 8> pVertices;
	pVertices[0] = CDiffusedVertex(XMFLOAT3(-fx, +fy, -fz),RANDOM_COLOR); // 앞면 좌상단 (0)
	pVertices[1] = CDiffusedVertex(XMFLOAT3(+fx, +fy, -fz),RANDOM_COLOR); // 앞면 우상단 (1)
	pVertices[2] = CDiffusedVertex(XMFLOAT3(+fx, -fy, -fz),RANDOM_COLOR); // 앞면 우하단 (2)
	pVertices[3] = CDiffusedVertex(XMFLOAT3(-fx, -fy, -fz),RANDOM_COLOR); // 앞면 좌하단 (3)
	pVertices[4] = CDiffusedVertex(XMFLOAT3(-fx, +fy, +fz),RANDOM_COLOR); // 뒷면 좌상단 (4)
	pVertices[5] = CDiffusedVertex(XMFLOAT3(+fx, +fy, +fz),RANDOM_COLOR); // 뒷면 우상단 (5)
	pVertices[6] = CDiffusedVertex(XMFLOAT3(+fx, -fy, +fz),RANDOM_COLOR); // 뒷면 우하단 (6)
	pVertices[7] = CDiffusedVertex(XMFLOAT3(-fx, -fy, +fz),RANDOM_COLOR); // 뒷면 좌하단 (7)

	CalculateBoundingBoxExtents(pVertices.data(), m_nVertices);
	
	// 정점 버퍼 GPU 업로드
	m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
		pVertices.data(), m_nVertices * m_nStride,
		D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, &m_pd3dVertexUploadBuffer);

	m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
	m_d3dVertexBufferView.StrideInBytes = m_nStride;
	m_d3dVertexBufferView.SizeInBytes = m_nStride * m_nVertices;


	// [핵심] 선(2개)이 아니라 삼각형(3개) 단위로 인덱스를 묶습니다.
	// 시계 방향(Clockwise)으로 점을 묶어야 앞면(Front Face)으로 인식됩니다!
	int nIndices = 36;
	int* pIndices = new int[nIndices];
	int indices[36] = {
		0, 1, 2,  0, 2, 3, // 앞면
		4, 6, 5,  4, 7, 6, // 뒷면
		4, 5, 1,  4, 1, 0, // 윗면
		3, 2, 6,  3, 6, 7, // 아랫면
		1, 5, 6,  1, 6, 2, // 오른쪽 면
		4, 0, 3,  4, 3, 7 // 왼쪽 면
	};

	m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
		pIndices, nIndices * sizeof(UINT),
		D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER, &m_pd3dIndexUploadBuffer);

	m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
	m_d3dIndexBufferView.Format = DXGI_FORMAT_R32_UINT;
	m_d3dIndexBufferView.SizeInBytes = nIndices * sizeof(UINT);
}

CCubeMesh::~CCubeMesh()
{
}
CPlaneMesh::CPlaneMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList,
                      float fWidth, float fDepth)
    : CMesh(pd3dDevice, pd3dCommandList)
{
    float fx = fWidth * 0.5f;
    float fz = fDepth * 0.5f;
 
    m_nVertices = 4;
    m_nStride = sizeof(CDiffusedVertex);
    m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
 
    // 바닥 타일은 동일한 회갈색 — 기존 SetColor(RGB(100,100,20))에 대응
    XMFLOAT4 xmf4FloorColor(100.0f / 255.0f, 100.0f / 255.0f, 20.0f / 255.0f, 1.0f);
 
    CDiffusedVertex pVertices[4];
    pVertices[0] = CDiffusedVertex(XMFLOAT3(-fx, 0.0f, -fz), xmf4FloorColor);
    pVertices[1] = CDiffusedVertex(XMFLOAT3(+fx, 0.0f, -fz), xmf4FloorColor);
    pVertices[2] = CDiffusedVertex(XMFLOAT3(+fx, 0.0f, +fz), xmf4FloorColor);
    pVertices[3] = CDiffusedVertex(XMFLOAT3(-fx, 0.0f, +fz), xmf4FloorColor);
 
    CalculateBoundingBoxExtents(pVertices, m_nVertices);
 
    m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pVertices, m_nStride * m_nVertices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER,
        &m_pd3dVertexUploadBuffer);
    m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
    m_d3dVertexBufferView.StrideInBytes  = m_nStride;
    m_d3dVertexBufferView.SizeInBytes    = m_nStride * m_nVertices;
 
    m_nIndices = 6;
    UINT pnIndices[6] = { 0, 2, 1,  0, 3, 2 }; // [기존 GDI와 동일]
 
    m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pnIndices, sizeof(UINT) * m_nIndices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER,
        &m_pd3dIndexUploadBuffer);
    m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
    m_d3dIndexBufferView.Format         = DXGI_FORMAT_R32_UINT;
    m_d3dIndexBufferView.SizeInBytes    = sizeof(UINT) * m_nIndices;
}
 
CPlaneMesh::~CPlaneMesh() {}
 
 
// ═════════════════════════════════════════════════════════
// CPlayerMesh — 전투기 형태 (15 정점, 28 삼각형 / 84 인덱스)
// [보존] 기존 GDI 버전의 정점·인덱스 그대로
// ═════════════════════════════════════════════════════════
CPlayerMesh::CPlayerMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList,
                       float fScale)
    : CMesh(pd3dDevice, pd3dCommandList)
{
    float s = fScale;
 
    m_nVertices = 15;
    m_nStride = sizeof(CDiffusedVertex);
    m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
 
    CDiffusedVertex pVertices[15];
 
    // --- 동체 (Fuselage) ---
    pVertices[0]  = CDiffusedVertex(XMFLOAT3(0.0f,         0.0f,        2.0f * s),  RANDOM_COLOR); // 노즈
    pVertices[1]  = CDiffusedVertex(XMFLOAT3(-0.5f * s,   -0.5f * s,    1.0f * s),  RANDOM_COLOR); // 좌하
    pVertices[2]  = CDiffusedVertex(XMFLOAT3(+0.5f * s,   -0.5f * s,    1.0f * s),  RANDOM_COLOR); // 우하
    pVertices[3]  = CDiffusedVertex(XMFLOAT3(+0.5f * s,   +0.5f * s,    1.0f * s),  RANDOM_COLOR); // 우상
    pVertices[4]  = CDiffusedVertex(XMFLOAT3(-0.5f * s,   +0.5f * s,    1.0f * s),  RANDOM_COLOR); // 좌상
    pVertices[5]  = CDiffusedVertex(XMFLOAT3(-0.25f * s,  -0.25f * s,   0.0f),       RANDOM_COLOR); // 좌하 (꼬리쪽)
    pVertices[6]  = CDiffusedVertex(XMFLOAT3(+0.25f * s,  -0.25f * s,   0.0f),       RANDOM_COLOR); // 우하
    pVertices[7]  = CDiffusedVertex(XMFLOAT3(+0.25f * s,  +0.25f * s,   0.0f),       RANDOM_COLOR); // 우상
    pVertices[8]  = CDiffusedVertex(XMFLOAT3(-0.25f * s,  +0.25f * s,   0.0f),       RANDOM_COLOR); // 좌상
    pVertices[9]  = CDiffusedVertex(XMFLOAT3(0.0f,         0.0f,       -1.0f * s),  RANDOM_COLOR); // 꼬리 끝
 
    // --- 주익 (Delta Wings) ---
    pVertices[10] = CDiffusedVertex(XMFLOAT3(-3.0f * s,   0.0f,         1.0f * s),  RANDOM_COLOR); // 좌익 끝
    pVertices[11] = CDiffusedVertex(XMFLOAT3(+3.0f * s,   0.0f,         1.0f * s),  RANDOM_COLOR); // 우익 끝
 
    // --- 수직 꼬리날개 ---
    pVertices[12] = CDiffusedVertex(XMFLOAT3(0.0f,        1.5f * s,    0.0f),       RANDOM_COLOR);
 
    // --- 수평 꼬리날개 ---
    pVertices[13] = CDiffusedVertex(XMFLOAT3(-2.0f * s,   0.0f,         0.0f),       RANDOM_COLOR);
    pVertices[14] = CDiffusedVertex(XMFLOAT3(+2.0f * s,   0.0f,         0.0f),       RANDOM_COLOR);
 
    CalculateBoundingBoxExtents(pVertices, m_nVertices);
 
    m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pVertices, m_nStride * m_nVertices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER,
        &m_pd3dVertexUploadBuffer);
    m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
    m_d3dVertexBufferView.StrideInBytes  = m_nStride;
    m_d3dVertexBufferView.SizeInBytes    = m_nStride * m_nVertices;
 
    // [기존 GDI와 동일한 인덱스]
    m_nIndices = 87;
    UINT pnIndices[87] = {
        // --- 노즈 부분 (4개 삼각형) ---
        0, 3, 4,
        0, 4, 1,
        0, 2, 3,
        0, 1, 2,
        // --- 동체 중간 (직육면체) ---
        1, 4, 8, 1, 8, 5, // 좌측면
        4, 3, 7, 4, 7, 8, // 상단면
        3, 2, 6, 3, 6, 7, // 우측면
        2, 1, 5, 2, 5, 6, // 하단면
        // --- 동체 후방 (4개 삼각형) ---
        5, 8, 9,
        8, 7, 9,
        7, 6, 9,
        6, 5, 9,
        // --- 동체 단면 마감 ---
        5, 6, 7, 5, 7, 8,
        1, 2, 3, 1, 3, 4,
        // --- 주익 ---
        4, 1, 10,
        1, 4, 10,
        2, 3, 11,
        3, 2, 11,
        // --- 수직 꼬리날개 ---
        8, 12, 7,
        // --- 수평 꼬리날개 ---
        8, 13, 5,
        5, 13, 8,
        7, 14, 6,
        6, 14, 7
    };
 
    m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pnIndices, sizeof(UINT) * m_nIndices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER,
        &m_pd3dIndexUploadBuffer);
    m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
    m_d3dIndexBufferView.Format         = DXGI_FORMAT_R32_UINT;
    m_d3dIndexBufferView.SizeInBytes    = sizeof(UINT) * m_nIndices;
}
 
CPlayerMesh::~CPlayerMesh() {}
 
 
// ═════════════════════════════════════════════════════════
// CEnemyMesh — 팔면체 본체 + 다리 + 안테나 (12 정점, 26 삼각형 / 78 인덱스)
// [보존] 기존 GDI 버전과 동일
// ═════════════════════════════════════════════════════════
CEnemyMesh::CEnemyMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList,
                     float fScale)
    : CMesh(pd3dDevice, pd3dCommandList)
{
    float s = fScale * 0.5f;
    float ls = s * 1.5f;
 
    m_nVertices = 12;
    m_nStride = sizeof(CDiffusedVertex);
    m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
 
    CDiffusedVertex pVertices[12];
 
    // --- 본체 (팔면체 6 정점) ---
    pVertices[0] = CDiffusedVertex(XMFLOAT3(0.0f,  s,    0.0f), RANDOM_COLOR);   // 위
    pVertices[1] = CDiffusedVertex(XMFLOAT3(0.0f, -s,    0.0f), RANDOM_COLOR);   // 아래
    pVertices[2] = CDiffusedVertex(XMFLOAT3(0.0f,  0.0f, s),    RANDOM_COLOR);   // 앞
    pVertices[3] = CDiffusedVertex(XMFLOAT3(s,    0.0f,  0.0f), RANDOM_COLOR);   // 우
    pVertices[4] = CDiffusedVertex(XMFLOAT3(0.0f, 0.0f, -s),    RANDOM_COLOR);   // 뒤
    pVertices[5] = CDiffusedVertex(XMFLOAT3(-s,   0.0f,  0.0f), RANDOM_COLOR);   // 좌
 
    // --- 다리 (피라미드 끝점 4개) ---
    pVertices[6] = CDiffusedVertex(XMFLOAT3( ls, -ls,  ls), RANDOM_COLOR);
    pVertices[7] = CDiffusedVertex(XMFLOAT3( ls, -ls, -ls), RANDOM_COLOR);
    pVertices[8] = CDiffusedVertex(XMFLOAT3(-ls, -ls, -ls), RANDOM_COLOR);
    pVertices[9] = CDiffusedVertex(XMFLOAT3(-ls, -ls,  ls), RANDOM_COLOR);
 
    // --- 안테나 (위쪽 피라미드 끝점 2개) ---
    pVertices[10] = CDiffusedVertex(XMFLOAT3(-s, ls, ls), RANDOM_COLOR);
    pVertices[11] = CDiffusedVertex(XMFLOAT3( s, ls, ls), RANDOM_COLOR);
 
    CalculateBoundingBoxExtents(pVertices, m_nVertices);
 
    m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pVertices, m_nStride * m_nVertices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER,
        &m_pd3dVertexUploadBuffer);
    m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
    m_d3dVertexBufferView.StrideInBytes  = m_nStride;
    m_d3dVertexBufferView.SizeInBytes    = m_nStride * m_nVertices;
 
    m_nIndices = 78;
    UINT pnIndices[78] = {
        // --- 본체 (팔면체 8 삼각형) ---
        0, 2, 3,   0, 3, 4,   0, 4, 5,   0, 5, 2,   // 상단 4개
        1, 3, 2,   1, 4, 3,   1, 5, 4,   1, 2, 5,   // 하단 4개
        // --- 다리 (각 다리 3 삼각형 × 4 = 12) ---
        1, 2, 6,   2, 3, 6,   3, 1, 6,
        1, 3, 7,   3, 4, 7,   4, 1, 7,
        1, 4, 8,   4, 5, 8,   5, 1, 8,
        1, 5, 9,   5, 2, 9,   2, 1, 9,
        // --- 안테나 (각 3 삼각형 × 2 = 6) ---
        0, 5, 10,  5, 2, 10,  2, 0, 10,
        0, 2, 11,  2, 3, 11,  3, 0, 11
    };
 
    m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pnIndices, sizeof(UINT) * m_nIndices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER,
        &m_pd3dIndexUploadBuffer);
    m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
    m_d3dIndexBufferView.Format         = DXGI_FORMAT_R32_UINT;
    m_d3dIndexBufferView.SizeInBytes    = sizeof(UINT) * m_nIndices;
}
 
CEnemyMesh::~CEnemyMesh() {}
 
 
// ═════════════════════════════════════════════════════════
// CWallMesh — 첨탑형 (9 정점, 14 삼각형 / 42 인덱스)
// ═════════════════════════════════════════════════════════
CWallMesh::CWallMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList,
                   float fWidth, float fHeight, float fDepth)
    : CMesh(pd3dDevice, pd3dCommandList)
{
    float w = fWidth * 0.5f;
    float d = fDepth * 0.5f;
    float h = fHeight;
    float sh = h * 0.8f;     // 어깨 높이
    float sw = w * 0.6f;
    float sd = d * 0.6f;
 
    m_nVertices = 9;
    m_nStride = sizeof(CDiffusedVertex);
    m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
 
    CDiffusedVertex pVertices[9];
    // 바닥 (0~3)
    pVertices[0] = CDiffusedVertex(XMFLOAT3(-w, 0.0f, -d),    RANDOM_COLOR);
    pVertices[1] = CDiffusedVertex(XMFLOAT3( w, 0.0f, -d),    RANDOM_COLOR);
    pVertices[2] = CDiffusedVertex(XMFLOAT3( w, 0.0f,  d),    RANDOM_COLOR);
    pVertices[3] = CDiffusedVertex(XMFLOAT3(-w, 0.0f,  d),    RANDOM_COLOR);
    // 어깨 (4~7)
    pVertices[4] = CDiffusedVertex(XMFLOAT3(-sw, sh, -sd),    RANDOM_COLOR);
    pVertices[5] = CDiffusedVertex(XMFLOAT3( sw, sh, -sd),    RANDOM_COLOR);
    pVertices[6] = CDiffusedVertex(XMFLOAT3( sw, sh,  sd),    RANDOM_COLOR);
    pVertices[7] = CDiffusedVertex(XMFLOAT3(-sw, sh,  sd),    RANDOM_COLOR);
    // 꼭짓점 (8)
    pVertices[8] = CDiffusedVertex(XMFLOAT3(0.0f, h, 0.0f),   RANDOM_COLOR);
 
    CalculateBoundingBoxExtents(pVertices, m_nVertices);
 
    m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pVertices, m_nStride * m_nVertices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER,
        &m_pd3dVertexUploadBuffer);
    m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
    m_d3dVertexBufferView.StrideInBytes  = m_nStride;
    m_d3dVertexBufferView.SizeInBytes    = m_nStride * m_nVertices;
 
    m_nIndices = 42;
    UINT pnIndices[42] = {
        // 측면 4개 (각 사다리꼴 = 2 삼각형)
        0, 4, 5,   0, 5, 1,
        1, 5, 6,   1, 6, 2,
        2, 6, 7,   2, 7, 3,
        3, 7, 4,   3, 4, 0,
        // 상단 피라미드 (4 삼각형)
        4, 8, 5,
        5, 8, 6,
        6, 8, 7,
        7, 8, 4,
        // 바닥 (2 삼각형)
        0, 1, 2,   0, 2, 3
    };
 
    m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pnIndices, sizeof(UINT) * m_nIndices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER,
        &m_pd3dIndexUploadBuffer);
    m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
    m_d3dIndexBufferView.Format         = DXGI_FORMAT_R32_UINT;
    m_d3dIndexBufferView.SizeInBytes    = sizeof(UINT) * m_nIndices;
}
 
CWallMesh::~CWallMesh() {}
 
 
// ═════════════════════════════════════════════════════════
// CMissileMesh — 사면체 (4 정점, 4 삼각형 / 12 인덱스)
// ═════════════════════════════════════════════════════════
CMissileMesh::CMissileMesh(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList,
                         float fScale)
    : CMesh(pd3dDevice, pd3dCommandList)
{
    float s = fScale * 0.5f;
 
    m_nVertices = 4;
    m_nStride = sizeof(CDiffusedVertex);
    m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
 
    // 미사일은 노란색 고정 — 기존 SetColor(RGB(255,255,0))에 대응
    XMFLOAT4 xmf4MissileColor(1.0f, 1.0f, 0.0f, 1.0f);
 
    CDiffusedVertex pVertices[4];
    pVertices[0] = CDiffusedVertex(XMFLOAT3(0.0f,  0.0f,  s),  xmf4MissileColor); // 끝점
    pVertices[1] = CDiffusedVertex(XMFLOAT3(-s,   -s,   -s),  xmf4MissileColor);
    pVertices[2] = CDiffusedVertex(XMFLOAT3( s,   -s,   -s),  xmf4MissileColor);
    pVertices[3] = CDiffusedVertex(XMFLOAT3(0.0f,  s,   -s),  xmf4MissileColor);
 
    CalculateBoundingBoxExtents(pVertices, m_nVertices);
 
    m_pd3dVertexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pVertices, m_nStride * m_nVertices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER,
        &m_pd3dVertexUploadBuffer);
    m_d3dVertexBufferView.BufferLocation = m_pd3dVertexBuffer->GetGPUVirtualAddress();
    m_d3dVertexBufferView.StrideInBytes  = m_nStride;
    m_d3dVertexBufferView.SizeInBytes    = m_nStride * m_nVertices;
 
    m_nIndices = 12;
    UINT pnIndices[12] = {
        0, 3, 1,
        0, 2, 3,
        0, 1, 2,
        1, 3, 2
    };
 
    m_pd3dIndexBuffer = ::CreateBufferResource(pd3dDevice, pd3dCommandList,
        pnIndices, sizeof(UINT) * m_nIndices,
        D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER,
        &m_pd3dIndexUploadBuffer);
    m_d3dIndexBufferView.BufferLocation = m_pd3dIndexBuffer->GetGPUVirtualAddress();
    m_d3dIndexBufferView.Format         = DXGI_FORMAT_R32_UINT;
    m_d3dIndexBufferView.SizeInBytes    = sizeof(UINT) * m_nIndices;
}
 
CMissileMesh::~CMissileMesh() {}