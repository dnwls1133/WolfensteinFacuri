﻿#include "stdafx.h"
#include "Shader.h"

CShader::CShader()
{
}

CShader::~CShader()
{
	if (m_ppd3dPipelineStates)
	{
		for (int i = 0; i < m_nPipelineStates; ++i)
			if (m_ppd3dPipelineStates[i]) m_ppd3dPipelineStates[i]->Release();
		delete[] m_ppd3dPipelineStates;
	}
}

// 래스터라이저 상태 - 기본값으로 와이어프레임이 아닌 솔리드, 뒷면 컬링, 깊이 클립 활성화

D3D12_RASTERIZER_DESC CShader::CreateRasterizerState()
{
	D3D12_RASTERIZER_DESC d3dRasterizerDesc;
	::ZeroMemory(&d3dRasterizerDesc, sizeof(D3D12_RASTERIZER_DESC));
	d3dRasterizerDesc.FillMode = D3D12_FILL_MODE_SOLID;
	d3dRasterizerDesc.CullMode = D3D12_CULL_MODE_BACK;
	d3dRasterizerDesc.FrontCounterClockwise = FALSE;
	d3dRasterizerDesc.DepthBias = 0;
	d3dRasterizerDesc.DepthBiasClamp = 0.0f;
	d3dRasterizerDesc.SlopeScaledDepthBias = 0.0f;
	d3dRasterizerDesc.DepthClipEnable = TRUE;
	d3dRasterizerDesc.MultisampleEnable = FALSE;
	d3dRasterizerDesc.AntialiasedLineEnable = FALSE;
	d3dRasterizerDesc.ForcedSampleCount = 0;
	d3dRasterizerDesc.ConservativeRaster = D3D12_CONSERVATIVE_RASTERIZATION_MODE_OFF;
	return d3dRasterizerDesc;
}

// 깊이-스텐실 상태 - Z버퍼 활성 (기존 페인터 알고리즘 대체)

D3D12_DEPTH_STENCIL_DESC CShader::CreateDepthStencilState()
{
	D3D12_DEPTH_STENCIL_DESC d3dDepthStencilDesc;
	::ZeroMemory(&d3dDepthStencilDesc, sizeof(D3D12_DEPTH_STENCIL_DESC));
	d3dDepthStencilDesc.DepthEnable = TRUE;
	d3dDepthStencilDesc.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL;
	d3dDepthStencilDesc.DepthFunc = D3D12_COMPARISON_FUNC_LESS;
	d3dDepthStencilDesc.StencilEnable = FALSE;
	d3dDepthStencilDesc.StencilReadMask = 0x00;
	d3dDepthStencilDesc.StencilWriteMask = 0x00;
	d3dDepthStencilDesc.FrontFace.StencilFailOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.FrontFace.StencilDepthFailOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.FrontFace.StencilPassOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.FrontFace.StencilFunc = D3D12_COMPARISON_FUNC_ALWAYS;
	d3dDepthStencilDesc.BackFace.StencilFailOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.BackFace.StencilDepthFailOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.BackFace.StencilPassOp = D3D12_STENCIL_OP_KEEP;
	d3dDepthStencilDesc.BackFace.StencilFunc = D3D12_COMPARISON_FUNC_ALWAYS;

	return d3dDepthStencilDesc;
}

// 블렌딩 상태 - 기본값으로 블렌딩 비활성화 (불투명 렌더링)

D3D12_BLEND_DESC CShader::CreateBlendState()
{
	D3D12_BLEND_DESC d3dBlendDesc;
	::ZeroMemory(&d3dBlendDesc, sizeof(D3D12_BLEND_DESC));
	d3dBlendDesc.AlphaToCoverageEnable = FALSE;
	d3dBlendDesc.IndependentBlendEnable = FALSE;
	d3dBlendDesc.RenderTarget[0].BlendEnable = FALSE;
	d3dBlendDesc.RenderTarget[0].LogicOpEnable = FALSE;
	d3dBlendDesc.RenderTarget[0].SrcBlend = D3D12_BLEND_ONE;
	d3dBlendDesc.RenderTarget[0].DestBlend = D3D12_BLEND_ZERO;
	d3dBlendDesc.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
	d3dBlendDesc.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
	d3dBlendDesc.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;
	d3dBlendDesc.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
	d3dBlendDesc.RenderTarget[0].LogicOp = D3D12_LOGIC_OP_NOOP;
	d3dBlendDesc.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
	return d3dBlendDesc;
}


D3D12_INPUT_LAYOUT_DESC CShader::CreateInputLayout()
{
	D3D12_INPUT_LAYOUT_DESC d3dInputLayoutDesc;
	::ZeroMemory(&d3dInputLayoutDesc, sizeof(D3D12_INPUT_LAYOUT_DESC));
	d3dInputLayoutDesc.pInputElementDescs = NULL;
	d3dInputLayoutDesc.NumElements = 0;
	return d3dInputLayoutDesc;
	
}

D3D12_SHADER_BYTECODE CShader::CreateVertexShader(ID3DBlob** ppd3dShaderBlob)
{
	D3D12_SHADER_BYTECODE d3dShaderByteCode;
	::ZeroMemory(&d3dShaderByteCode, sizeof(D3D12_SHADER_BYTECODE));
	d3dShaderByteCode.BytecodeLength = 0;
	d3dShaderByteCode.pShaderBytecode = NULL;
	return d3dShaderByteCode;
}

D3D12_SHADER_BYTECODE CShader::CreatePixelShader(ID3DBlob** ppd3dShaderBlob)
{
	D3D12_SHADER_BYTECODE d3dShaderByteCode;
	::ZeroMemory(&d3dShaderByteCode, sizeof(D3D12_SHADER_BYTECODE));
	d3dShaderByteCode.BytecodeLength = 0;
	d3dShaderByteCode.pShaderBytecode = NULL;
	return d3dShaderByteCode;
}

// HLSL 파일에서 셰이더 컴파일 -> 바이트 코드 변환

D3D12_SHADER_BYTECODE CShader::CompileShaderFromFile(WCHAR* pszFileName, LPSTR pszShaderName, LPSTR pszShaderProfile, ID3DBlob** ppd3dShaderBlob)
{
	UINT nCompileFlags = 0;
#if defined(_DEBUG)
	nCompileFlags = D3DCOMPILE_DEBUG | D3DCOMPILE_SKIP_OPTIMIZATION;
#endif
	
	// ─────────────────────────────────────────────────────
   // .exe가 있는 폴더 기준으로 절대 경로 구성
   // (작업 디렉토리에 의존하지 않게 안전하게 처리)
   // ─────────────────────────────────────────────────────
	WCHAR szFullPath[MAX_PATH];
	::GetModuleFileNameW(NULL, szFullPath, MAX_PATH);

	// 마지막 백슬래시 뒤를 잘라 폴더 경로만 남김
	WCHAR* pszLastSlash = wcsrchr(szFullPath, L'\\');
	if (pszLastSlash) *(pszLastSlash + 1) = L'\0';

	// 그 폴더에 셰이더 파일명 붙임
	wcscat_s(szFullPath, MAX_PATH, pszFileName);

	// 디버그 출력 — Visual Studio의 출력 창에서 확인 가능
	::OutputDebugStringW(L"[Shader] Trying to compile: ");
	::OutputDebugStringW(szFullPath);
	::OutputDebugStringW(L"\n");

	// ─────────────────────────────────────────────────────
	// 셰이더 컴파일
	// ─────────────────────────────────────────────────────
	ID3DBlob* pd3dErrorBlob = NULL;
	HRESULT hr = ::D3DCompileFromFile(szFullPath, NULL, NULL,
		pszShaderName, pszShaderProfile,
		nCompileFlags, 0, ppd3dShaderBlob, &pd3dErrorBlob);

	if (FAILED(hr) || !(*ppd3dShaderBlob))
	{
		if (pd3dErrorBlob)
		{
			::OutputDebugStringA((char*)pd3dErrorBlob->GetBufferPointer());
			::MessageBoxA(NULL,
				(char*)pd3dErrorBlob->GetBufferPointer(),
				"Shader Compile Error", MB_OK | MB_ICONERROR);
			pd3dErrorBlob->Release();
		}
		else
		{
			// 어떤 경로로 시도했는지 메시지 박스에 표시
			char szMsg[1024];
			char szPathA[MAX_PATH];
			::WideCharToMultiByte(CP_ACP, 0, szFullPath, -1, szPathA, MAX_PATH, NULL, NULL);
			sprintf_s(szMsg,
				"Failed to find/compile shader file.\n\n"
				"HRESULT = 0x%08X\n\n"
				"Tried path:\n%s\n\n"
				"Please copy Shaders.hlsl to that folder.",
				hr, szPathA);
			::MessageBoxA(NULL, szMsg, "Shader File Error", MB_OK | MB_ICONERROR);
		}

		D3D12_SHADER_BYTECODE d3dShaderByteCode;
		d3dShaderByteCode.BytecodeLength = 0;
		d3dShaderByteCode.pShaderBytecode = NULL;
		return d3dShaderByteCode;
	}

	D3D12_SHADER_BYTECODE d3dShaderByteCode;
	d3dShaderByteCode.BytecodeLength = (*ppd3dShaderBlob)->GetBufferSize();
	d3dShaderByteCode.pShaderBytecode = (*ppd3dShaderBlob)->GetBufferPointer();
	return d3dShaderByteCode;

}

// PSO 생성 - 모든 파이프라인 상태 컴포넌트를 결합

void CShader::CreateShader(ID3D12Device* pd3dDevice, ID3D12RootSignature* pd3dRootSignature)
{
	ID3DBlob* pd3dVertexShaderBlob = NULL;
	ID3DBlob* pd3dPixelShaderBlob = NULL;

	D3D12_GRAPHICS_PIPELINE_STATE_DESC d3dPipelineStateDesc;
	::ZeroMemory(&d3dPipelineStateDesc, sizeof(D3D12_GRAPHICS_PIPELINE_STATE_DESC));
	d3dPipelineStateDesc.pRootSignature			= pd3dRootSignature;
	d3dPipelineStateDesc.VS						= CreateVertexShader(&pd3dVertexShaderBlob);
	d3dPipelineStateDesc.PS						= CreatePixelShader(&pd3dPixelShaderBlob);
	d3dPipelineStateDesc.RasterizerState		= CreateRasterizerState();
	d3dPipelineStateDesc.BlendState				= CreateBlendState();
	d3dPipelineStateDesc.DepthStencilState		= CreateDepthStencilState();
	d3dPipelineStateDesc.InputLayout			= CreateInputLayout();
	d3dPipelineStateDesc.SampleMask				= UINT_MAX;
	d3dPipelineStateDesc.PrimitiveTopologyType	= D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
	d3dPipelineStateDesc.NumRenderTargets		= 1;
	d3dPipelineStateDesc.RTVFormats[0]			= DXGI_FORMAT_R8G8B8A8_UNORM;	
	d3dPipelineStateDesc.DSVFormat				= DXGI_FORMAT_D24_UNORM_S8_UINT;
	d3dPipelineStateDesc.SampleDesc.Count		= 1;
	d3dPipelineStateDesc.Flags					= D3D12_PIPELINE_STATE_FLAG_NONE;

	pd3dDevice->CreateGraphicsPipelineState(&d3dPipelineStateDesc,
		__uuidof(ID3D12PipelineState), (void**)&m_ppd3dPipelineStates[0]);

	if (pd3dVertexShaderBlob) pd3dVertexShaderBlob->Release();
	if (pd3dPixelShaderBlob) pd3dPixelShaderBlob->Release();
	if (d3dPipelineStateDesc.InputLayout.pInputElementDescs)
		delete[] d3dPipelineStateDesc.InputLayout.pInputElementDescs;


}

void CShader::CretaeShaderVariables(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList)
{
}

void CShader::UpdateShaderVariables(ID3D12GraphicsCommandList* pd3dCommandList)
{
}

void CShader::ReleaseShaderVariables()
{
}

// 게임 오브젝트 월드 행렬 -> b0 슬롯
// HLSL은 열우선 행렬이므로, CPU에서 전치하여 전달

void CShader::UpdateShaderVariables(ID3D12GraphicsCommandList* pd3dCommandList, XMFLOAT4X4* pxmf4x4World)
{
	XMFLOAT4X4 xmf4x4World;
	XMStoreFloat4x4(&xmf4x4World, XMMatrixTranspose(XMLoadFloat4x4(pxmf4x4World)));
	pd3dCommandList->SetGraphicsRoot32BitConstants(0, 16, &xmf4x4World, 0);
}

// 매 프레임 PSO 바인딩

void CShader::OnPrepareRender(ID3D12GraphicsCommandList* pd3dCommandList)
{
	pd3dCommandList->SetPipelineState(m_ppd3dPipelineStates[0]);
}

void CShader::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera)
{
	OnPrepareRender(pd3dCommandList);
}


// ═════════════════════════════════════════════════════════
// CDiffusedShader : 위치+색상 정점용 셰이더
// ═════════════════════════════════════════════════════════
CDiffusedShader::CDiffusedShader()
{
}
CDiffusedShader::~CDiffusedShader()
{
}

// InputLayout - CDiffusedVertex 메모리 레이아웃과 정확히 매칭
// offset 12 = sizeof(XMFLOAT3 m_xmf3Position)

D3D12_INPUT_LAYOUT_DESC CDiffusedShader::CreateInputLayout()
{
	UINT nInputElementDesce = 2;
	D3D12_INPUT_ELEMENT_DESC* pd3dInputElementDescs = new D3D12_INPUT_ELEMENT_DESC[nInputElementDesce];
	pd3dInputElementDescs[0] = { "POSITION" , 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,0,
	D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA , 0};

	pd3dInputElementDescs[1] = { "COLOR" , 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0,12,
	D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA , 0};

	D3D12_INPUT_LAYOUT_DESC d3dInputLayoutDesc;
	d3dInputLayoutDesc.pInputElementDescs = pd3dInputElementDescs;
	d3dInputLayoutDesc.NumElements = nInputElementDesce;
	return d3dInputLayoutDesc;
}

D3D12_SHADER_BYTECODE CDiffusedShader::CreateVertexShader(ID3DBlob** ppd3dShaderBlob)
{
	return CShader::CompileShaderFromFile(
		const_cast<WCHAR*>(L"Shaders.hlsl"),
		const_cast<LPSTR>("VSDiffused"),
		const_cast<LPSTR>("vs_5_1"),
		ppd3dShaderBlob);
}

D3D12_SHADER_BYTECODE CDiffusedShader::CreatePixelShader(ID3DBlob** ppd3dShaderBlob)
{
	return CShader::CompileShaderFromFile(
		const_cast<WCHAR*>(L"Shaders.hlsl"),
		const_cast<LPSTR>("PSDiffused"),
		const_cast<LPSTR>("ps_5_1"),
		ppd3dShaderBlob);
}

void CDiffusedShader::CreateShader(ID3D12Device* pd3dDevice, ID3D12RootSignature* pd3dRootSignature)
{
	m_nPipelineStates = 1;
	m_ppd3dPipelineStates = new ID3D12PipelineState * [m_nPipelineStates];
	CShader::CreateShader(pd3dDevice, pd3dRootSignature);
}
