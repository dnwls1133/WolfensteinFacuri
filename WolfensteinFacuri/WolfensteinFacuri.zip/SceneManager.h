#pragma once
#include "Scene.h"
class CScene;

class CSceneManager
{
public:
	static CSceneManager* GetInstance()
	{
		static CSceneManager instance;
		return &instance;
	}

	CSceneManager(const CSceneManager&) = delete; 
	CSceneManager& operator=(const CSceneManager&) = delete;

	CSceneManager() {};
	virtual ~CSceneManager() {};

private:
	CScene* m_pCurrentScene{ nullptr }; // ���� Ȱ��ȭ�� ���� ������

public:
	void SetCurrentScene(CScene* pScene) { m_pCurrentScene = pScene; }
	CScene* GetCurrentScene() const { return m_pCurrentScene; }


};

