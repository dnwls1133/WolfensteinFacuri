﻿#include "stdafx.h"
#include "GraphicsPipeline.h"
#include "Enemy.h"
#include "Wall.h"
#include "Scene.h"


CScene::CScene(CPlayer* pPlayer)
	: m_pPlayer(pPlayer)
{

	
}

CScene::~CScene()
{
	ReleaseObjects();

	//[D3d12 추가] 셰이더 및 루트 시그니처 해제
	if (m_pShader) m_pShader->Release();
	if (m_pd3dGrahpicsRootSignature) m_pd3dGrahpicsRootSignature->Release();

	if (m_pMissileMesh) m_pMissileMesh->Release();
	if (m_pParticleMesh) m_pParticleMesh->Release();
	if (m_pEnemyMesh) m_pEnemyMesh->Release();
}



// [D3D12 추가] Root Signature 생성
// Root Parameter 0 : b0
// Root Parameter 1 : b1 

void CScene::CreateGraphicsRootSignature(ID3D12Device* pd3dDevice)
{
	D3D12_ROOT_PARAMETER pd3dRootParameters[2];
	::ZeroMemory(pd3dRootParameters, sizeof(pd3dRootParameters));

	// b0 : CB_GAMEOBJECT_INFO (게임 객체별 상수 버퍼)
	pd3dRootParameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
	pd3dRootParameters[0].Descriptor.ShaderRegister = 0; // b0
	pd3dRootParameters[0].Descriptor.RegisterSpace = 0;
	pd3dRootParameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_VERTEX;

	// b1 : CB_SCENE_INFO (씬 전체 상수 버퍼)
	pd3dRootParameters[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
	pd3dRootParameters[1].Descriptor.ShaderRegister = 1; // b1
	pd3dRootParameters[1].Descriptor.RegisterSpace = 0;
	pd3dRootParameters[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_VERTEX;

	// IA 활성화 플래그
	D3D12_ROOT_SIGNATURE_FLAGS d3dRootSignatureFlags = 
		D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_HULL_SHADER_ROOT_ACCESS |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_DOMAIN_SHADER_ROOT_ACCESS |
		D3D12_ROOT_SIGNATURE_FLAG_DENY_GEOMETRY_SHADER_ROOT_ACCESS;

	D3D12_ROOT_SIGNATURE_DESC d3dRootSignatureDesc;
	::ZeroMemory(&d3dRootSignatureDesc, sizeof(d3dRootSignatureDesc));
	d3dRootSignatureDesc.NumParameters = _countof(pd3dRootParameters);
	d3dRootSignatureDesc.pParameters = pd3dRootParameters;
	d3dRootSignatureDesc.NumStaticSamplers = 0;
	d3dRootSignatureDesc.pStaticSamplers = nullptr;
	d3dRootSignatureDesc.Flags = d3dRootSignatureFlags;

	ID3DBlob* pd3dSignatureBlob = NULL;
	ID3DBlob* pd3dErrorBlob = NULL;
	::D3D12SerializeRootSignature(&d3dRootSignatureDesc,
		D3D_ROOT_SIGNATURE_VERSION_1, &pd3dSignatureBlob, &pd3dErrorBlob);

	pd3dDevice->CreateRootSignature(0,
		pd3dSignatureBlob->GetBufferPointer(),
		pd3dSignatureBlob->GetBufferSize(),
		__uuidof(ID3D12RootSignature),
		(void**)&m_pd3dGrahpicsRootSignature);

	if (pd3dSignatureBlob) pd3dSignatureBlob->Release();
	if (pd3dErrorBlob) pd3dErrorBlob->Release();
}

void CScene::BuildObjects(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList)
{
	// 공용으로 쓸 큐브 메쉬 딱 1개만 생성한다.
	m_pd3dDevice = pd3dDevice;
	m_pd3dCommandList = pd3dCommandList;

	// 1. Root Signature 생성
	CreateGraphicsRootSignature(pd3dDevice);
	m_pShader = new CDiffusedShader();
	m_pShader->CreateShader(pd3dDevice, m_pd3dGrahpicsRootSignature);
	m_pShader->AddRef();

	// 2. 메쉬 생성
	m_pEnemyMesh = new CEnemyMesh(pd3dDevice, pd3dCommandList, 1.0f);
	m_pEnemyMesh->AddRef();
	CPlayerMesh* pPlayerMesh = new CPlayerMesh(pd3dDevice, pd3dCommandList, 1.0f);
	float         fChunkSize = 10.0f;
	CPlaneMesh* pPlaneMesh = new CPlaneMesh(pd3dDevice, pd3dCommandList, fChunkSize, fChunkSize);
	CWallMesh* pWallMesh = new CWallMesh(pd3dDevice, pd3dCommandList, 10.0f, 10.0f, 10.0f);
	

	m_pMissileMesh = new CMissileMesh(pd3dDevice, pd3dCommandList, 0.5f);
	m_pParticleMesh = new CCubeMesh(pd3dDevice, pd3dCommandList, 0.2f);

	m_pMissileMesh->AddRef();
	m_pParticleMesh->AddRef();

	// ─────────────────────────────────────────────────────
	// 3. 플레이어 설정 (기존 로직 동일)
	// ─────────────────────────────────────────────────────
	m_pPlayer->SetMesh(pPlayerMesh);
	m_pPlayer->SetShader(m_pShader);
	m_pPlayer->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	
	// ─────────────────────────────────────────────────────
	// 4. 적 20개 생성 (기존 로직 동일 — Z축 방향으로 일렬 배치)
	// ─────────────────────────────────────────────────────
	m_xmf3Enemyspawnposition = XMFLOAT3(0.0f, 0.0f, 0.0f);
	for (int i = 0; i < 20; i++)
	{
		CEnemy* pEnemy = new CEnemy();
		pEnemy->SetMesh(m_pEnemyMesh);
		pEnemy->SetShader(m_pShader);
		pEnemy->CreateShaderVariables(pd3dDevice, pd3dCommandList);

		float X = m_xmf3Enemyspawnposition.x + (rand() / (float)RAND_MAX - 0.5f) * 100.0f;
		float Y = m_xmf3Enemyspawnposition.y + (rand() / (float)RAND_MAX - 0.5f) * 10.0f;
		float Z = m_xmf3Enemyspawnposition.z + i * 20.0f;
		pEnemy->SetPosition(X, Y, Z);
		pEnemy->GenerateBoundingBox();

		pEnemy->SetColor(RGB(rand() % 150 + 100, rand() % 150 + 100, rand() % 150 + 100));
		pEnemy->SetObjectType(OBJ_ENEMY);

		m_vpObjects.push_back(pEnemy);
		++m_nObjects;
	}

	// ─────────────────────────────────────────────────────
	// 5. 바닥 타일 30x50 = 1500개 (기존 로직 동일)
	// ─────────────────────────────────────────────────────
	int nMapWidth = 30;
	int nMapDepth = 50;
	for (int Z = 0; Z < nMapDepth; Z++)
	{
		for (int X = 0; X < nMapWidth; X++)
		{
			CGameObject* pFloor = new CGameObject();
			pFloor->SetMesh(pPlaneMesh);
			pFloor->SetShader(m_pShader);
			pFloor->CreateShaderVariables(pd3dDevice, pd3dCommandList);

			float fPosX = (X - nMapWidth / 2.0f) * fChunkSize;
			float fPosZ = (Z - nMapDepth / 2.0f) * fChunkSize;
			pFloor->SetPosition(fPosX, -5.0f, fPosZ);

			pFloor->SetColor(RGB(100, 100, 20));
			pFloor->SetObjectType(OBJ_FLOOR);

			m_vpObjects.push_back(pFloor);
			m_vpFloorObjects.push_back(pFloor);
			++m_nObjects;
		}
	}

	// ─────────────────────────────────────────────────────
	// 6. 벽 500개 좌우 배치 (기존 로직 동일)
	// ─────────────────────────────────────────────────────
	m_xmf3Wallposition = XMFLOAT3(0.0f, -4.0f, 0.0f);

	const int   nWallCount = 500;
	const int   nWallsPerSide = nWallCount / 2;
	const float wallHalfOffsetX = 50.0f;
	const float wallSpacingZ = 12.0f;

	for (int i = 0; i < nWallCount; ++i)
	{
		CWall* pWall = new CWall();
		pWall->SetMesh(pWallMesh);
		pWall->SetShader(m_pShader);
		pWall->CreateShaderVariables(pd3dDevice, pd3dCommandList);

		bool bLeftSide = (i < nWallsPerSide);
		int  indexOnSide = bLeftSide ? i : (i - nWallsPerSide);

		float startZ = m_xmf3Wallposition.z - ((nWallsPerSide - 1) * wallSpacingZ * 0.5f);
		float fPosX = m_xmf3Wallposition.x + (bLeftSide ? -wallHalfOffsetX : wallHalfOffsetX);
		float fPosZ = startZ + (indexOnSide * wallSpacingZ);

		pWall->SetPosition(fPosX, -4.0f, fPosZ);
		pWall->SetColor(RGB(rand() % 50 + 100, rand() % 50 + 100, rand() % 50 + 100));
		pWall->GenerateBoundingBox();
		pWall->SetObjectType(OBJ_WALL);

		m_vpObjects.push_back(pWall);
		m_vpWallObjects.push_back(pWall);
		++m_nObjects;
	}


}

void CScene::AddObject(CGameObject* pObject)
{
	if (!pObject) return; 
	const int nMaxBullets = 240;
	const int nMaxEffects = 24;

	ObjectType type = pObject->GetObjectType();


	if (type == OBJ_BULLET && m_nBulletObjects >= nMaxBullets)
	{
		delete pObject;
		return;
	}
	if (type == OBJ_EFFECT && m_nEffectObjects >= nMaxEffects)
	{
		delete pObject;
		return;
	}

	if (pObject && m_pd3dDevice)
	{
		pObject->SetShader(m_pShader);
		pObject->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);
	}

	m_vpObjects.push_back(pObject);
	++m_nObjects;

	if (type == OBJ_BULLET) ++m_nBulletObjects;
	else if (type == OBJ_EFFECT) ++m_nEffectObjects;
}

void CScene::ReleaseObjects()
{
	if (!m_vpObjects.empty())
	{
		for (int i = 0; i < m_nObjects; i++) delete m_vpObjects[i];
		m_vpObjects.clear();
	}
}

void CScene::ClearGarbageCollection()
{
	for (int i =0; i < m_vpObjects.size();)
	{
		if (m_vpObjects[i]->IsDestroyed())
		{
			ObjectType type = m_vpObjects[i]->GetObjectType();
			delete m_vpObjects[i];

			m_vpObjects[i] = m_vpObjects.back();
			m_vpObjects.pop_back();
			--m_nObjects;

			if (type == OBJ_BULLET && m_nBulletObjects > 0) --m_nBulletObjects;
			else if (type == OBJ_EFFECT && m_nEffectObjects > 0) --m_nEffectObjects;
		}
		else
		{
			i++; // 삭제하지 않은 경우에만 인덱스 증가
		}

	}


}



void CScene::Animate(float fElapsedTime)
{


	XMFLOAT3 floorPosition = m_vpFloorObjects[450]->GetPosition();
	
	XMFLOAT3 playerPosition = m_pPlayer->GetPosition();

	float Fdistance = Vector3::Distance(floorPosition, playerPosition);
	float Wdistance = Vector3::Distance(m_xmf3Wallposition, playerPosition);
	float Edistance = Vector3::Distance(m_xmf3Enemyspawnposition, playerPosition);
	
	if (Fdistance > 50.0f)
	{
		int nMapWidth = 30; // 맵의 가로 크기 (바닥 조각 수)
		int nMapDepth = 50; // 맵의 세로 크기 (바닥 조각 수)
		float fChunkSize = 10.0f; // 각 바닥 조각의 크기

		// 플레이어의 위치를 가장 가까운 바닥 조각의 중심으로 스냅
		float snappedX = round(playerPosition.x / fChunkSize) * fChunkSize;
		float snappedZ = round(playerPosition.z / fChunkSize) * fChunkSize;

		for (int i = 0; i < m_vpFloorObjects.size(); i++)
		{
			int gridX = i % nMapWidth; // X 좌표 계산
			int gridZ = i / nMapWidth; // Z 좌표 계산

			float newX = snappedX + (gridX - nMapWidth / 2.0f) * fChunkSize; // 새로운 X 좌표 계산
			float newZ = snappedZ + (gridZ - nMapDepth / 2.0f) * fChunkSize; // 새로운 Z 좌표 계산

			float currentY = m_vpFloorObjects[i]->GetPosition().y; // 현재 Y 좌표 유지

			m_vpFloorObjects[i]->SetPosition(newX, currentY, newZ); // 바닥 조각의 위치 업데이트

		}

	}
	

	if (Wdistance > 300.0f)
	{
		playerPosition.z += 300.0f;

		m_xmf3Wallposition = playerPosition;


		const int nWallCount = static_cast<int>(m_vpWallObjects.size());
		const int nWallsPerSide = nWallCount / 2;
		const float wallHalfOffsetX = 50.0f;  // 양옆 거리
		const float wallSpacingZ = 12.0f;      // 벽 간격(Z축)

		float startZ = m_xmf3Wallposition.z - ((nWallsPerSide - 1) * wallSpacingZ * 0.5f);

		for (int i = 0; i < nWallCount; ++i)
		{
			bool bLeftSide = (i < nWallsPerSide);
			int indexOnSide = bLeftSide ? i : (i - nWallsPerSide);

			float fPosX = m_xmf3Wallposition.x + (bLeftSide ? -wallHalfOffsetX : wallHalfOffsetX);
			float fPosZ = startZ + (indexOnSide * wallSpacingZ);

			m_vpWallObjects[i]->SetPosition(fPosX, -3.0f, fPosZ); // Y 좌표는 0으로 설정하여 바닥 위에 위치하도록 함
		}
	}

	if (Edistance > 200.0f)
	{
		playerPosition.z += 50.0f;
		m_xmf3Enemyspawnposition = playerPosition;

		int nEnemyCount = std::count_if(m_vpObjects.begin(),m_vpObjects.end(),
			[](CGameObject* pObj) { return pObj->GetObjectType() == OBJ_ENEMY; });

		int enemyIndex = 0;
		for (int i = 0; i < (int)m_vpObjects.size(); i++)
		{
			if (m_vpObjects[i]->GetObjectType() == OBJ_ENEMY)
			{
				float fPosX = m_xmf3Enemyspawnposition.x + (rand() / (float)RAND_MAX - 0.5f) * 100.0f;
				float fPosY = m_xmf3Enemyspawnposition.y + (rand() / (float)RAND_MAX - 0.5f) * 10.0f;
				float fPosZ = m_xmf3Enemyspawnposition.z + enemyIndex * 20.0f;
				m_vpObjects[i]->SetPosition(fPosX, fPosY, fPosZ);
				++enemyIndex;
			}
		}

		if (nEnemyCount < 20)
		{
			for (int i = 0; i < 20 - nEnemyCount; i++)
			{
				CEnemy* pEnemy = new CEnemy();
				pEnemy->SetMesh(m_pEnemyMesh);
				float fPosX = m_xmf3Enemyspawnposition.x + (rand() / (float)RAND_MAX - 0.5f) * 100.0f;
				float fPosY = m_xmf3Enemyspawnposition.y + (rand() / (float)RAND_MAX - 0.5f) * 10.0f;
				float fPosZ = m_xmf3Enemyspawnposition.z + i * 20.0f;
				pEnemy->SetPosition(fPosX, fPosY, fPosZ);
				pEnemy->GenerateBoundingBox();
				pEnemy->SetColor(RGB(rand() % 150 + 100, rand() % 150 + 100, rand() % 150 + 100));
				pEnemy->SetObjectType(OBJ_ENEMY);
				AddObject(pEnemy);
			}
		}
		

		
	}

	lightDir = Vector3::Normalize(lightDir); // 광원 방향 벡터를 정규화하여 사용
	lightDir = Vector3::TransformNormal(lightDir, XMMatrixRotationY(fElapsedTime * 0.1f)); // 광원 방향을 시간에 따라 회전시킴
	for (auto& object : m_vpObjects)
	{
		if (!object->IsActive()) continue; // 비활성화된 객체는 업데이트 안 함
		object->Update(); // 월드 행렬 갱신

	}
	if (m_pPlayer) m_pPlayer->Update();

	m_mapCollisionGroups.clear(); // 매 프레임마다 충돌 그룹을 새로 만들어야 하므로 맵 초기화

	if (m_pPlayer) m_mapCollisionGroups[m_pPlayer->GetObjectType()].push_back(m_pPlayer); // 플레이어는 OBJ_PLAYER 그룹에 추가

	for (int i = 0; i < m_nObjects; i++)
	{
		if(m_vpObjects[i]->IsActive() && !m_vpObjects[i]->IsDestroyed())
			m_mapCollisionGroups[m_vpObjects[i]->GetObjectType()].push_back(m_vpObjects[i]); // 각 객체는 자신의 타입 그룹에 추가
		
	}

	CheckAllCollisions(); // 매 프레임마다 충돌 검사
}



void CScene::InitCollisionMatrix()
{
	m_setCollisionMatrix.insert({ OBJ_PLAYER, OBJ_MONSTER }); 
	m_setCollisionMatrix.insert({ OBJ_PLAYER, OBJ_ENEMY });
	m_setCollisionMatrix.insert({ OBJ_ENEMY, OBJ_BULLET });
	m_setCollisionMatrix.insert({ OBJ_PLAYER, OBJ_WALL });
}

void CScene::CheckAllCollisions()
{
	std::unordered_set<ULONGLONG> setCurrentCollisions; // 이번 프레임에 충돌하는 쌍들의 모임

	for (const auto& pair : m_setCollisionMatrix)
	{
		int typeA = pair.first;
		int typeB = pair.second;


		CheckCollisionGroup(m_mapCollisionGroups[typeA], m_mapCollisionGroups[typeB], setCurrentCollisions);
	}

	// 3. 이전 프레임에는 충돌했지만 이번 프레임에는 충돌하지 않는 쌍들을 찾아서 충돌 종료 처리
	for (const auto& key : m_setPreviousCollisions)
	{
		if (setCurrentCollisions.find(key) == setCurrentCollisions.end())
		{
			UINT keyA = (UINT)(key >> 32); // 상위 32비트에서 객체 A의 ID 추출
			UINT keyB = (UINT)(key & 0xFFFFFFFF); // 하위 32비트에서 객체 B의 ID 추출

			CGameObject* pObjA = FindGameObject(keyA);
			CGameObject* pObjB = FindGameObject(keyB);

			if (!pObjA || !pObjB) continue; // 객체가 이미 삭제된 경우 무시

			pObjA->EndCollision(pObjB);
			pObjB->EndCollision(pObjA);

		}
	}

	m_setPreviousCollisions = std::move(setCurrentCollisions); // 이번 프레임의 충돌 쌍들을 이전 프레임으로 이동
}

CGameObject* CScene::FindGameObject(UINT nID)
{
	// 현재 충돌 그룹 전체에서 찾기 (플레이어/적/탄환 모두 대응)
	for (auto& pair : m_mapCollisionGroups)
	{
		for (CGameObject* pObj : pair.second)
		{
			if (pObj && pObj->m_nObjectID == nID)
			{
				return pObj;
			}
		}
	}
	return nullptr;
}

void CScene::CheckCollisionGroup(std::vector<CGameObject*>& groupA, std::vector<CGameObject*>& groupB, std::unordered_set<ULONGLONG>& setCurrentCollisions)
{
	


	for (auto& pObjA : groupA)
	{
		for (auto& pObjB : groupB)
		{
			if (pObjA == pObjB) continue; // 같은 객체끼리는 충돌 검사 안 함
			if(pObjA->m_xmOOBB.Intersects(pObjB->m_xmOOBB))
			{
				// 1. 고유한 충돌 키 생성
				ULONGLONG key = GetCollisionKey(pObjA, pObjB);

				setCurrentCollisions.insert(key); // 이번 프레임에 충돌하는 쌍으로 추가

				// 2. 이전 프레임에도 충돌했던 쌍인지 확인
				if (m_setPreviousCollisions.find(key) == m_setPreviousCollisions.end())
				{
					// 이전 프레임에는 충돌하지 않았던 쌍 -> 충돌 시작
					pObjA->StartCollision(pObjB);
					pObjB->StartCollision(pObjA);
				}
				else
				{
					// 이전 프레임에도 충돌했던 쌍 -> 충돌 지속
					pObjA->OnCollision(pObjB);
					pObjB->OnCollision(pObjA);
				}

			}
		}
	}

	

}


void CScene::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera)	
{
	
	// 1. Root Signature 바인딩
	pd3dCommandList->SetGraphicsRootSignature(m_pd3dGrahpicsRootSignature);

	// 2. 뷰포트/가위 + 카메라 상수 버퍼(b1) 갱신/바인딩
	pCamera->SetViewportsAndScissorRects(pd3dCommandList);
	pCamera->UpdateShaderVariables(pd3dCommandList);

	// 3. 절두체 컬링 
	std::vector<CGameObject*> vEffectObjects;
	vEffectObjects.reserve(128);

	for (int i = 0; i < m_nObjects; ++i)
	{
		if (m_vpObjects[i]->IsDestroyed()) continue;

		XMFLOAT3 objPos = m_vpObjects[i]->GetPosition();
		if (!pCamera->IsInFrustum(objPos, 1.0f))
		{
			m_vpObjects[i]->SetActive(false);
			continue;
		}
		m_vpObjects[i]->SetActive(true);

		// 이펙트는 따로 모았다가 마지막에
		if (m_vpObjects[i]->GetObjectType() == OBJ_EFFECT)
		{
			vEffectObjects.push_back(m_vpObjects[i]);
			continue;
		}

		// 일반 오브젝트: 즉시 렌더
		m_vpObjects[i]->Render(pd3dCommandList, pCamera);
	}

	// 4) 플레이어 (절두체 안에 있으면 렌더)
	if (m_pPlayer)
	{
		XMFLOAT3 playerPos = m_pPlayer->GetPosition();
		if (pCamera->IsInFrustum(playerPos, 4.0f))
			m_pPlayer->Render(pd3dCommandList, pCamera);
	}

	// 5) 이펙트(파티클) 렌더 — 마지막에
	for (auto* pEffect : vEffectObjects)
	{
		pEffect->Render(pd3dCommandList, pCamera);
	}
}