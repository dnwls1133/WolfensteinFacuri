#pragma once
#include "GameObject.h"
#include "Camera.h"
#include "Missile.h"

class CPlayer : public CGameObject
{
public:
	CPlayer();
	virtual ~CPlayer();

protected:
	CCamera* m_pCamera{ NULL }; 


	int m_nHealth = 10; 
	float m_fPlayTime = 0.0f;
	bool m_playerDestroyed = false; // �÷��̾ �ı��Ǿ����� ���θ� ��Ÿ���� �÷���
	bool m_playerWon = false;


public:
	void SetCamera(CCamera* pCamera) { m_pCamera = pCamera; }
	CCamera* GetCamera() const { return m_pCamera; }
	bool IsDestroyed() const { return m_playerDestroyed; }
	bool IsWon() const { return m_playerWon; }
	
	void SetWon() { m_playerWon = true; }

	void Move(DWORD dwDirection, float fDistance);
	void Rotate(float fPitch, float fYaw, float fRoll);




	//void FireMissile(); // �̻��� �߻� �Լ�

	virtual void Update() override;

public:
	virtual void StartCollision(CGameObject* pOther) override
	{
		if (pOther->GetObjectType() == OBJ_ENEMY)
		{
			--m_nHealth; // ���� �浹 �� ü�� ����
		}
		if (pOther->GetObjectType() == OBJ_WALL || pOther->GetObjectType() == OBJ_MONSTER)
		{
			//m_nHealth = 0; // ���� �浹 �� ü�� ����
		}
		
	}
	virtual void OnCollision(CGameObject* pOther) override
	{
		
		
	}
	virtual void EndCollision(CGameObject* pOther) override
	{
		
	}
   
};

