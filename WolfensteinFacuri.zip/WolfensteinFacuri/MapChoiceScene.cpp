#include "stdafx.h"
#include "ChoiceCube.h"
#include "Text.h"
#include "WFSMap1Scene.h"
#include "WFSMap2Scene.h"
#include "GalagaScene.h"
#include "MapChoiceScene.h"

MapChoiceScene::MapChoiceScene(CColliderManager* pCollider, CCamera* pCamera)
	: CScene(pCollider, pCamera)
{
}

void MapChoiceScene::Animate(float fElapsedTime)
{
	CScene::Animate(fElapsedTime);
}

void MapChoiceScene::ProcessInput(const InputState& InputState, float fElapsedTime)
{
	const UCHAR* pKeyBuffer = InputState.keys;

	static bool bLeftClick = false;
	if (pKeyBuffer[VK_LBUTTON] & 0x80)
	{
		if (!bLeftClick)
		{
			bLeftClick = true;

			float mouseX = static_cast<float>(InputState.mousePosition.x);
			float mouseY = static_cast<float>(InputState.mousePosition.y);

			XMFLOAT3 vNear = m_pCamera->ScreenToWorld(mouseX, mouseY, 0.0f); // �� ��� ��ǥ
			XMFLOAT3 vFar = m_pCamera->ScreenToWorld(mouseX, mouseY, 1.0f); // �� ��� ��ǥ

			// Ray�� �������� Direction ���
			XMVECTOR vRayOrigin = XMLoadFloat3(&vNear);
			XMVECTOR vRayFar = XMLoadFloat3(&vFar);
			XMVECTOR vRayDirection = XMVector3Normalize(XMVectorSubtract(vRayFar, vRayOrigin));

			// Ray�� �浹�ϴ� ��ü OBB �˻�
			float fMinDist = FLT_MAX;
			CGameObject* pSelectedObject = nullptr;

			for (CGameObject* pObject : m_vpObjects)
			{
				if (!pObject->IsActive() || pObject->IsDestroyed()) continue;

				float fDist = 0.0f;

				if (pObject->m_xmOOBB.Intersects(vRayOrigin, vRayDirection, fDist))
				{
					if (fDist < fMinDist)
					{
						fMinDist = fDist;
						pSelectedObject = pObject;
					}
				}


			}

			// ���õ� ��ü�� ������ ó��
			if (pSelectedObject && pSelectedObject->GetObjectType() == OBJ_CHOICE)
			{
				CChoiceCube* pChoice = static_cast<CChoiceCube*>(pSelectedObject);
				switch(pChoice->m_nChoiceID)
				{
				case 1:
					SCENE_MANAGER->RequestSceneChange(new WFSMap1Scene(m_pColliderManager, m_pCamera));
					break;
				case 2:
					SCENE_MANAGER->RequestSceneChange(new WFSMap2Scene(m_pColliderManager, m_pCamera));
					break;
				}
			}


		}
		else
		{
			bLeftClick = false; // Ŭ���� ������ �� �÷��� �ʱ�ȭ
		}


	}
}

void MapChoiceScene::BuildSceneObjects()
{
	m_pPlayer = new CPlayer();
	m_pPlayer->SetCamera(m_pCamera);
	m_pPlayer->SetPosition(0.0f, 0.0f, -100.0f);
	m_pPlayer->SetObjectType(OBJ_PLAYER);
	// �÷��̾� ���� ����
	m_pPlayer->SetColor(XMFLOAT4(1.0f, 1.0f, 1.0f, 1.f));

	m_pPlayer->SetMesh(m_pPlayerMesh);
	m_pPlayer->SetShader(m_pShader);
	m_pPlayer->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);

	CChoiceCube* pChoiceCube = new CChoiceCube();
	pChoiceCube->SetPosition(-25.0f, 0.0f, -50.0f);
	pChoiceCube->SetObjectType(OBJ_CHOICE);
	pChoiceCube->SetMesh(m_pCubeMesh);
	pChoiceCube->SetShader(m_pShader);
	pChoiceCube->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);
	pChoiceCube->SetColor(XMFLOAT4(1.0f, 0.0f, 0.0f, 1.f)); // ���������� ����
	pChoiceCube->GenerateBoundingBox(); // OOBB ����
	pChoiceCube->m_nChoiceID = 1; 
	AddObject(pChoiceCube);

	CText* pChoiceText = new CText(TEXT_CHOICE);
	pChoiceText->SetPosition(-25.0f, 0.0f, -75.0f); // �ؽ�Ʈ ��ġ ����
	pChoiceText->SetObjectType(OBJ_TEXT);
	pChoiceText->SetMesh(m_vpTextMeshes[2]);
	pChoiceText->SetShader(m_pShader);
	pChoiceText->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);
	pChoiceText->SetColor(XMFLOAT4(1.0f, 1.0f, 1.0f, 1.f)); // �ؽ�Ʈ ���� ����
	pChoiceText->GenerateBoundingBox(); // �ؽ�Ʈ ��ü�� OOBB ����
	AddObject(pChoiceText); // ���� �ؽ�Ʈ ��ü �߰�

	// �ٸ� ���� ť�� �߰� (����)
	CChoiceCube* pChoiceCube2 = new CChoiceCube();
	pChoiceCube2->SetPosition(25.0f, 0.0f, -50.0f);
	pChoiceCube2->SetObjectType(OBJ_CHOICE);
	pChoiceCube2->SetMesh(m_pCubeMesh);
	pChoiceCube2->SetShader(m_pShader);
	pChoiceCube2->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);
	pChoiceCube2->SetColor(XMFLOAT4(0.0f, 0.0f, 1.0f, 1.f)); // �Ķ������� ����
	pChoiceCube2->GenerateBoundingBox(); // OOBB ����
	pChoiceCube2->m_nChoiceID = 2;
	AddObject(pChoiceCube2);

	CText* pChoiceText2 = new CText(TEXT_CHOICE);
	pChoiceText2->SetPosition(25.0f, 0.0f, -75.0f); // �ؽ�Ʈ ��ġ ����
	pChoiceText2->SetObjectType(OBJ_TEXT);
	pChoiceText2->SetMesh(m_vpTextMeshes[3]);
	pChoiceText2->SetShader(m_pShader);
	pChoiceText2->CreateShaderVariables(m_pd3dDevice, m_pd3dCommandList);
	pChoiceText2->SetColor(XMFLOAT4(1.0f, 1.0f, 1.0f, 1.f)); // �ؽ�Ʈ ���� ����
	pChoiceText2->GenerateBoundingBox(); // �ؽ�Ʈ ��ü�� OOBB ����
	AddObject(pChoiceText2); // ���� �ؽ�Ʈ ��ü �߰�

}
void MapChoiceScene::UpdateCamera(float fElapsedTime)
{
	if (!m_pCamera) return;

	m_pCamera->SetPosition(0.0f, 0.0f, -150.0f);
	m_pCamera->Update();
}
