#pragma once
#include "Player.h"
class CAircraft :
    public CPlayer
{
public:
    CAircraft();
    virtual ~CAircraft() = default;

public:
    float m_fFireCooldown = 0.1f;
    float m_fLastFireTime = 0.0f;
public:

    void FireMissile(); // �̻��� �߻� �Լ�

	virtual void Update() override;

public:
	virtual void StartCollision(CGameObject* pOther) override
	{
		if (pOther->GetObjectType() == OBJ_ENEMY)
		{
			--m_nHealth; // ���� �浹 �� ü�� ����
		}
		if (pOther->GetObjectType() == OBJ_WALL || pOther->GetObjectType() == OBJ_MONSTER)
		{
			//m_nHealth = 0; // ���� �浹 �� ü�� ����
		}

	}
	virtual void OnCollision(CGameObject* pOther) override
	{


	}
	virtual void EndCollision(CGameObject* pOther) override
	{

	}
};

